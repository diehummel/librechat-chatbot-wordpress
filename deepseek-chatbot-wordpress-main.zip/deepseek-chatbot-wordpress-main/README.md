# deepseek-chatbot-wordpress
A try for a deepseek chatbot wordpress plugin

To be able to use the Deepseek API you must Top up the minimout of money at https://platform.deepseek.com/usage

Installation:
Download the Repo as ZIP and install it in Wordpress via Plugin Manager.
